% Function to add noise
function y = add_noise(x)
    y = x + 0.5*randn(size(x));
end