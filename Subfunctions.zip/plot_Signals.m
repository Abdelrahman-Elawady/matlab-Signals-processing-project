% Function to plot signals
function plot_Signals(x, y1, y2, y3)
    subplot(3, 1, 1);
    plot(x, y1, 'r-');
    title('Original Signal');
    xlabel('Time');
    ylabel('Amplitude');
    
    subplot(3, 1, 2);
    plot(x, y2, 'b-');
    title('Noisy Signal');
    xlabel('Time');
    ylabel('Amplitude');
    
    subplot(3, 1, 3);
    plot(x, y3, 'g-');
    title('Filtered Signal');
    xlabel('Time');
    ylabel('Amplitude');
end
