% Function to filter noise
function y = filter_noise(x, type)
    switch type
        case 1
            y = smoothdata(x, 'movmean', 5);
        case 2
            y = smoothdata(x, 'gaussian', 5);
        case 3
            y = smoothdata(x, 'sgolay');
        otherwise
            y = smoothdata(x, 'movmean', 5);
    end
end