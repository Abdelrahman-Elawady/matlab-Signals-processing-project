% Function to generate a signal
function y = generate_signal(x, type, frequency)
    switch type
        case 1
            y = sin(2*pi*x*frequency);
        case 2
            y = cos(2*pi*x*frequency);
        case 3
            y = square(2*pi*x*frequency);
        otherwise
            y = sin(2*pi*x*frequency);
    end
end
